package com.example.comp3606asgbirds;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerBirds;
    CheckBox chkPreviousOwner;
    EditText etCost;
    ImageView imgBird;
    Button btnCalc, btnSMS;

    String[] birds = {"Canary", "Finch", "Robin"};
    double[] prices = {500.0, 600.0, 700.0};
    double cost = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerBirds = findViewById(R.id.spinnerBirds);
        chkPreviousOwner = findViewById(R.id.chkPreviousOwner);
        etCost = findViewById(R.id.etCost);
        imgBird = findViewById(R.id.imgBird);
        btnCalc = findViewById(R.id.btnCalc);
        btnSMS = findViewById(R.id.btnSMS);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, birds);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBirds.setAdapter(adapter);

        spinnerBirds.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0: imgBird.setImageResource(R.drawable.canary); break;
                    case 1: imgBird.setImageResource(R.drawable.finch); break;
                    case 2: imgBird.setImageResource(R.drawable.robin); break;
                    default: imgBird.setImageResource(R.drawable.ic_launcher_foreground); break;
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        btnCalc.setOnClickListener(v -> {
            int pos = spinnerBirds.getSelectedItemPosition();
            double basePrice = prices[pos];
            if (chkPreviousOwner.isChecked()) {
                cost = basePrice * 0.8;
            } else {
                cost = basePrice;
            }
            String costStr = String.format("%.2f", cost);
            etCost.setText(costStr);
            Toast.makeText(MainActivity.this, "Cost: $" + costStr, Toast.LENGTH_SHORT).show();
        });

        btnSMS.setOnClickListener(v -> {
            String costText = etCost.getText().toString().trim();
            if (TextUtils.isEmpty(costText)) {
                Toast.makeText(MainActivity.this, "Please calculate cost first.", Toast.LENGTH_SHORT).show();
                return;
            }

            String selectedBird = spinnerBirds.getSelectedItem().toString();
            String smsBody = "You selected a " + selectedBird + " for $" + costText +
                    " from Haley Skeete's Birds!";

            Intent smsIntent = new Intent(Intent.ACTION_VIEW);
            smsIntent.setData(Uri.parse("sms:"));
            smsIntent.putExtra("sms_body", smsBody);

            try {
                startActivity(smsIntent);
                Toast.makeText(MainActivity.this, "SMS is ready to send!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Failed to open SMS app.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
